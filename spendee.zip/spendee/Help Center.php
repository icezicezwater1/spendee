<?php
include 'connect.php';
session_start();
//if(!isset($_SESSION['username'])){
    //header('location:login.php');
//}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FAQs</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-image: linear-gradient(#0F1035, #365486, #7FC7D9, #DCF2F1);
            margin: 0;
            padding: 0;
            height: 100vh;
        }

        h2 {
            text-align: center;
            color: #3498db;
        }

        #goBack {
            text-align: center;
            margin-top: 20px;
        }

        #goBack a {
            display: inline-block;
            padding: 8px 16px;
            text-decoration: none;
            background-color: #3498db;
            color: #fff;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        #goBack a:hover {
            background-color: #2980b9;
        }

        .search-container {
            text-align: center;
            margin-top: 20px;
        }

        #searchInput {
            padding: 10px;
            width: 70%;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .help-topics {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            margin-top: 20px;
        }

        .help-topic {
            margin: 10px;
            padding: 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            background-color: #fff;
            width: 250px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s, box-shadow 0.3s;
            cursor: pointer;
        }

        .help-topic:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        }

        .help-topic a {
            text-decoration: none;
            color: #333;
            font-weight: bold;
            font-size: 16px;
        }
    </style>
</head>
<body>

<h2>Help Center</h2>

<div class="search-container">
    <input type="text" id="searchInput" placeholder="Search...">
</div>

<div id="helpcenter" class="help-topics">
    <div class="help-topic"><a href="https://youtu.be/cjDjos6R2zk">How to add an expense?</a></div>
    <div class="help-topic"><a href="https://central.xero.com/s/article/Edit-or-delete-an-expense-on-a-project">How to edit an expense?</a></div>
</div>

<div id="filteredhelpcenter"></div>

<script src="https://cdn.jsdelivr.net/npm/fuse.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        var helpListItems = Array.from(document.getElementById('helpcenter').children);

        var fuse = new Fuse(helpListItems, {
            keys: ['textContent'],
            threshold: 0.4
        });

        var searchInput = document.getElementById('searchInput');
        searchInput.addEventListener('input', performSearch);

        function performSearch() {
            var searchResults = fuse.search(searchInput.value);

            var filteredList = document.getElementById('filteredhelpcenter');
            filteredList.innerHTML = '';

            searchResults.forEach(result => {
                var listItem = document.createElement('div');
                listItem.textContent = result.item.textContent;
                filteredList.appendChild(listItem);
            });
        }
    });
</script>

</body>
</html>
