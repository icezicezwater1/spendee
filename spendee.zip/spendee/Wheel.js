
document.addEventListener('DOMContentLoaded', function () {
    var financialData = {
        money: 0,
        spending: 0,
        savings: 0,
        investments: 0
    };

    var ctx = document.getElementById('financialCanvas').getContext('2d');
    var financialChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Money', 'Spending', 'Savings', 'Investments'],
            datasets: [{
                data: [financialData.money, financialData.spending, financialData.savings, financialData.investments],
                backgroundColor: ['#3498db', '#e74c3c', '#2ecc71', '#f39c12']
            }]
        },
        options: {
            cutout: '50%',
            responsive: true,
            maintainAspectRatio: false,
            legend: {
                display: true,
                position: 'bottom'
            },
            plugins: {
                draggable: {
                    enabled: true,
                    onDrag: function (event, datasetIndex, index, value) {
                        console.log('Drag event:', event);
                    },
                }
            }
        }
    });
});

