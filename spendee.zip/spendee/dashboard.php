<?php
include 'connect.php';

//if(!isset($_SESSION['username'])){
    //header('location:login.php');
//}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styleforDB.css">
    <title>Expense Tracker Dashboard</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>

<div class="container">
    <h2 class="text-center">Welcome to Your Dashboard</h2>

    <section class="profile-section"><br>
        <h3>Profile</h3>
        <p>Username: <span id="username"></span></p>
        <a href="edit_dash.php" class="btn btn-danger">Edit Profile</a>

    </section>

    <section class="financial-section">
        <h3>Your Financial Situation</h3>
        <div class="financial-wheel">
            <canvas id="financialCanvas" width="710" height="400" style="display: block; box-sizing: border-box; height: 200px; width: 355px;"></canvas>
        </div>
    </section>

    <section class="expense-form">
        <h3>Add Financial Data</h3>
        <label for="expenseCategory">Category:</label>
        <input type="text" id="expenseCategory" name="expenseCategory" required="">
        <label for="expenseAmount">Amount:</label>
        <input type="number" id="expenseAmount" name="expenseAmount" min="0" step="1" required="">
        <button onclick="trackExpense()">Expense tracking</button>
        
        <h3>Track Spendee</h3>
        <label for="spendingCategory"> Category:</label>
        <input type="text" id="spendingCategory" name="spendingCategory" required="">
        <label for="spendingAmount"> Amount:</label>
        <input type="number" id="spendingAmount" name="spendingAmount" min="0" step="1" required="">
        <button onclick="updateSpending()">Update Spendee</button>
        <button onclick="resetExpenseList()">Reset Expense List</button>
    </section>

    <section class="expense-list">
        <h3>Expense List</h3>
        <ul id="expenseList"></ul>
    </section>

    <div id="goBack">
        <a href="login.php" class="back-btn">Log out</a>
        <a href="Help Center.php" id="go-to-btn">Go to Help Center</a>
    </div>

</div>
<script>
    function toggleEditProfile() {
        var editProfileForm = document.getElementById("editProfileForm");
        editProfileForm.style.display = (editProfileForm.style.display === "none") ? "block" : "none";
    }

    function updateUsername() {
        var newUsername = document.getElementById('newUsername').value;
        document.getElementById('username').innerText = newUsername;
        sessionStorage.setItem('username', newUsername);
        toggleEditProfile();
    }

    function trackExpense() {
        var expenseCategory = document.getElementById('expenseCategory').value;
        var expenseAmount = document.getElementById('expenseAmount').value;

        financialData[expenseCategory.toLowerCase()] += parseFloat(expenseAmount) || 0;
        updateFinancialChart();

        var expenseList = document.getElementById('expenseList');
        var listItem = document.createElement('li');
        listItem.textContent = expenseCategory + ': $' + parseFloat(expenseAmount).toFixed(2);
        expenseList.appendChild(listItem);

        saveExpenseList();
    }

    function updateSpending() {
        var spendingCategory = document.getElementById('spendingCategory').value;
        var spendingAmount = document.getElementById('spendingAmount').value;

        financialData.spending -= parseFloat(spendingAmount) || 0;
        updateFinancialChart();

        var expenseList = document.getElementById('expenseList');
        var listItem = document.createElement('li');
        listItem.textContent = spendingCategory + ': $' + parseFloat(spendingAmount).toFixed(2);
        expenseList.appendChild(listItem);

        saveExpenseList();
    }

    function resetExpenseList() {
        var expenseList = document.getElementById('expenseList');
        expenseList.innerHTML = '';
        localStorage.removeItem('expenseList');
    }

    function updateFinancialChart() {
        financialChart.data.datasets[0].data = [financialData.money, financialData.spending, financialData.savings, financialData.investments];
        financialChart.update();
    }

    function saveExpenseList() {

        var expenseList = document.getElementById('expenseList').innerHTML;
        localStorage.setItem('expenseList', expenseList);
    }

    var storedUsername = sessionStorage.getItem('username');
    document.getElementById('username').innerText = storedUsername || 'JohnDoe';

    var financialData = {
        money: 0,
        spending: 0,
        savings: 0,
        investments: 0
    };

    var ctx = document.getElementById('financialCanvas').getContext('2d');
    var financialChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Money', 'Spending', 'Savings', 'Investments'],
            datasets: [{
                data: [financialData.money, financialData.spending, financialData.savings, financialData.investments],
                backgroundColor: ['#3498db', '#e74c3c', '#2ecc71', '#f39c12']
            }]
        },
        options: {
            cutout: '80%',
            responsive: true,
            maintainAspectRatio: false,
            legend: {
                display: true,
                position: 'bottom'
            }
        }
    });
</script>

</body>
</html>
