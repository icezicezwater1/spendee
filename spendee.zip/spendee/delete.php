<?php
include "connect.php";
$id = $_GET["id"];
$sql = "DELETE FROM `registration` WHERE id = $id";
$result = mysqli_query($con, $sql);

if ($result) {
    header("Location: edit_dash.php?msg=Data deleted successfully");
} else {
    echo "Failed: " . mysqli_error($con);
}